import 'package:get/get.dart';

class PostController extends GetxController {}
