import 'package:flutter/animation.dart';

class AppColors {
  static Color blackColor = const Color(0xFF000000);
  static Color whiteColor = const Color(0xFFFFFFFF);
}
