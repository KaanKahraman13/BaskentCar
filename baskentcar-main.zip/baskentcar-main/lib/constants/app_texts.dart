class AppTexts {
  static String signUpScreenHelpButtonText =
      "Tüm bilgilerini girdikten sonra kod gönder butonuna bastığınızda öğrenci mailine gelen kodu aşağıdaki kısma girerek kayıt işleminizi tamamlayabilirsiniz.";
}
